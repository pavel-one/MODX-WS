<?php

$_lang['area_wsexample_main'] = 'Основные';

$_lang['setting_wsexample_some_setting'] = 'Какая-то настройка';
$_lang['setting_wsexample_some_setting_desc'] = 'Это описание для какой-то настройки';