<?php
/**
 * English permissions Lexicon Entries for WsExample
 *
 * @package WsExample
 * @subpackage lexicon
 */
$_lang['wsexample_save'] = 'Разрешает создание/изменение данных.';