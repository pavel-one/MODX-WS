<?php
/**
 * Russian permissions Lexicon Entries for WsExample
 *
 * @package WsExample
 * @subpackage lexicon
 */
$_lang['wsexample_save'] = 'Permission for save/update data.';