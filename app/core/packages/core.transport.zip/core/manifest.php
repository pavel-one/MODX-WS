<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1e713ffcff56a538621e5df5b30a6f82',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/2d4e1820ce25f67005dd7622004bb848.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '9c01553b1597adf389fdd6f45282a680',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/3d5e9c724c8bc5a656955792d3255021.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => '1d1b26edbfdd3fa6da330fdab27f10ff',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/ba4453e5560074fef2f0bb8e33fd8547.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '6e19dfbc66ee44d45fd4a3cd3afecd37',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/5ca3bf18f0173b885924662e8b7afce1.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '730a27e54e08ee64706e8bffcdd258e8',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/dd0026b3608bfc172b74d8c6775793be.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'fa55c69461e6e298c518268882c6c25e',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/60c42095057f8c2ac764dd8fea80e047.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '4983b1accdd745b47935479c831e4f45',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/cc6ddabc617ccedfcd29d7cd2f8e173d.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '96eb1457c2ecd0e4e3cd9d6f845dd1ac',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/dd82dd0b67ecf94c0241e2a67c184864.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '9429f7db44ddc0e49eaa9b92aef7ce5f',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/629928fb4ceb45aa0d6376cc73f17c4a.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'f36b9877fe13b850faf3c8b95f66a88f',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/4c19412dcb33ad24d84b51b92e457d67.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '18004eb93ef72098a24e95fa8632f59a',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/21f9c6c5744ee3a15dd1c927e80e7047.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '8dadd7d54183856d7e6a8fed47251583',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/7e7091d61931d5b910ec4f4e925ba91e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ea1c0e809d860b6d11bab579ae99055b',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/901b6c0e2b234581d2085b745c458193.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c3a27297bb42679b19f27309f6cd448',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/54918ae26ddf592ee9dc612fd878a166.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04c0afe62cf0b7c600ba533f8be11270',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/f1f25deffc32244e027647f93ba18ca2.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '45432ebd14c6a7c5a6ba914ed6747442',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/741b64d624624a031b5ea9a59918c016.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '697c80967f80b5525c636ba8ca9c5966',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/e984e7cf6fd8e1d9f00c19b5cc828572.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4cc137666d1c2daef0774a88099bcea3',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/f67e277686e6a69f3636516f77c86389.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dda48870c8d0209d480a4a35aa11194d',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c2e5ae2bc5225b1377fd70f300e89b47.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7c9274b53a043839aea784bc944ca98a',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/faded4140cb1c29ff5c15762deef7df8.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2e5aac262af79d80b994d8cd41f31b9c',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/682939584e9721c95a79e654a08f7b9c.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd17e893bc2675b7c64b2de89ffa347f7',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c8bdcd9ff504ed4f91d423bde239d671.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a345e843ac77d86d01000667c1812796',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/57334f8381fe029e923876cf2b80e29d.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f8a6bff7a7a9f739edde07ed21cea1f9',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/53cf8363c73eaea0b1501ea261438bd4.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1ca63de412fb144a105b2d94291577f1',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/69dfa8745a028c074af1f9463b0f55e1.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7510c30f9cfe0cc86e7faec706bcacaf',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/788194b7fff9707ddf0746ed0aeaf2f5.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3803af9899675a0282d3bbb2c5bee919',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/2f4ceae284cf56a8adb850e745756f92.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e1f214856404a21a775ed9996dc801d0',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/35dbddb2e53fd55d6796101fbfa6c181.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ce7822f9a5d53a2cc951750ee59c519f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/44a053556eda6b7d65120e36c6fad6a0.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c0958174e407330871c098f04be25f72',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/be1c4db38f185a843c9aad73d04b5043.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0713056c7da402101e28cd87c93050ac',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6a1a55c5b450fe18b799cf250dd53175.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '564b602b64d1c5ffc2ba8ea3ee562e82',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7f7cdef0d37e61f74a60a49502940ef9.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd45b1d991b77dd250f42485dd10cb50a',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/bf866cda452c29b17ae6382dc3817652.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd0d666e3b52b57a3fdc62f96bf99a752',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/9d6dc86a06fa817de91da670467064fc.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5fd0f77bee8b48fe188de42da22e1d7c',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/9fe0f14bf8a0db678dedd8793fb09f95.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ba82cc92fc13f4ac65d521f324b880d4',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/61b7947365254c36d3a980c1f4d12cb2.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd21e039c7c409dd2e78cc54765ab1796',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/9214ad935512142d5dd0dbd4b4dbdfa8.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06c1cdbdd9da118e5f066b6a63c31dcc',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/49d946d9c1c596aca6e5523997d182a3.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1178ac128e3e5ca8cdeb58039bddc03d',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/9a56b2cbc158dcf4f78054673444872e.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '42f2bd1ad157145041a566fd96094c4f',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6a7c395b6fff920f64ebd94ca4c5c9f2.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '65606d0f1e98513d157762bd56be9985',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ddf584aa33e3f116d269a254dc72d024.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bbb8dfe03970c3bb02eebf7d20c83d8d',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e72471b1b82aef512e0e69770f521be5.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71c3b914d360900b290645a62ad03864',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/5e0fa5524608f8ffa21ae8fdcbf3f740.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6544725358335ff14e7c77913010da5d',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0ddd6d4713788c751a0c83152e7524c3.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7300e86b396aa728154a271fefc1f5e1',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/4b2e4cb8ee4756570a3127798aac36b0.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6310c6928355e818c48e9b29d62103e9',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/60d982c6b6329a9975e6314c17e10a25.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '03d005f7f61cc29c1eb7481df7a1b2cb',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/59a127a549bff2b5b189545e27ee1291.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d0214d32635b98b63fb2bf281c2738f',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/0fa9143e50055e98dd7ff1d57067a2eb.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '985e7e4bc7a5581ecbab026b38dd0abd',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/79fa47d6a3aaab2c42242e1f4d6e7d5d.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a55ab836c4e88cf7ae701f2654384d0c',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/15257f4804685c48cd09e233f2ab3d73.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '361a8501519289f857ae490be5636566',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/9e1e2761a8df23d6930094471ff48b4b.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f96179e3f634b8599309a22cec66cf55',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/5453aa972a0eb13b1c1dacde532f7b86.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6c3288f3961d208875ef5266ebacb58e',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/a8e28464db45473ca4f0fa5910007069.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41a16ba323fb5fba5a5c4ffc51ae23d6',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/30477b88f0601d6449e072385a7e58b8.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '753351d5b0431ec27a8ee37713ba5f94',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/de0830fd5b15b6fe807e5cb6d5abe32b.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0cc97ce902a8a947b617ff218abcdc32',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/aa7fd1dd197e881e2d41a5bc520aecbe.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09d5bf94222e333f87ddbaf9ba2af618',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/de55c93d109263f290579186eb2bbf42.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd7911213e6423f66d31e0c4d5dae535',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e5a407b2f4e797f3f7cbcef082b7b724.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '857a78c18d11238a5b9edaad3e3ae473',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/c6a27803db2a084a7aed35c0e62e1267.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c47c67c460c599d77e7a0617ab85cf2b',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/5a3aa962edf28ce0340d41085441a8c2.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '86575ea311d9864f6108aa80593dfcbb',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/0d1ce2744a1cb256b6389489fe780f35.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f87f4ef8d442c4d50665bdfadbbd7db',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/575a9e4109deb162a693b77558773b53.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '95440c8182990d50ae86e653cfce134c',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/8bdba1de469aa34eada6d54f1ea4e0cc.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6bf15dbc7113860af401fdb047c2cdb9',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7f6417f806fdcb9cfaaaee36f6dc4cf6.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9f454ee26ce396f6a7f8b58e9b822b31',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/c70c71828f9fc97e8bea61d873054d66.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '14cc53f9053718bd9b4bb5e50355487b',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/34b5759b126a885d477512be48c622e3.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '78f50c8f4044ffdddd6a7316323f0c55',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/ab7b983dba52aae93e6c8b1c542ad5e5.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7fd88ad5b1e27c049c7af676bb6ca879',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/2cf07ae351da0aea4edbf6252fbcfc27.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b88c46f5ddd8eb8c2a3ae8cb80861f2d',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/6abe29ddb52b9bfa5fe040aa2a1e36e1.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9162b0a52af30271e4a0fc8f77dedf33',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/f8b94c60a135cc39ec01247700aa5da8.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8e8782f78db401d900d414bc752b195e',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/8ff23f6d5c66e945227a74c579e10e00.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b1767ddbff74c125248347e70f5952c',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/07c28393b85514ca84e9e255a6d004ca.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04328ac1826ec31bcc23fe4e1554a828',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f8a64f1b989825bb0af009d85ee5846e.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1717043c2e68bfe74bb8dd55d49f3fdf',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/42055477150c2dea78e714389c855593.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2a136170d95636f136e7a97d12aef075',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/29bc19d1fb9e83648c5a6550f6b081d7.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b19abc437d9cb144550f0787dbac1633',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/798648c503bb0438af6aa948213bfd04.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '329232b24e26ade1a60f3b27e473e819',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/da7fe84509b7ccbd75f6471524013e55.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '63d97a1b0a7f2886ac8d980be4f05bcb',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/1441e650a000a0936433c596e208388e.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28153c58073c8b6605ff78d7dc39f62b',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/0128a0cde641d7b67be0b4b5428b2a96.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c87687ff1c3f03fccdf713e89e522b54',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/fe5bae5ca190b3dbe0536f359e40dd36.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a87ade8f6bfd1706cd1c1532f9b9dad3',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/e8348226240d61477b9d0f9f1f2c3303.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fa9d021bfe2ee1b1c6ccd4122dfed611',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/7e22568179ee4e784d7e7405f75f0109.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25042371a17d4e974c7adc379584886f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/a7a8614459b4b64f79f6a469e1b40322.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '005320b0f7fe91fdc0ff4afa2afff674',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/58bcc8b4f8ac78d44b05ebcf1d6f7f2d.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '56a3eddfa1a93168e76f609aa6533b28',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/9a236d92296f1839161bc1ef920a080e.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a4fbe43c27dc47f6db1d6e04da2c3363',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/0d28f9b315a1e0ddc2c7d2ab0c1bf2e5.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '77158a26f081a5618d16621d425ada2e',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/1bb3fafc58801fe184a81d8f9dd4de83.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e93b5a511b906a9e9298d4015a24065a',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/720b1da44f7555b5bd56152def07cf29.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9a347a248e84b10675c6dfce80d3cb3e',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/2ccd8820e3cf1ff43a6a1ca291311796.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eca90ddffbdf8813d20c2fa7b3683c9d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/9f59a141e26c3811dac582b970929d21.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '57c9e3b7154871e56cbef4d72e7e1103',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/7426dbfe2ff65c4a27d73fa52ca71881.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6ac4ac9d0ecfbe9b41b9735bb344cdf6',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/63c08037c257427ca24db86acba5736e.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6c88a8b553af7d1437755244ed5b975',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/ade5975e3a4effd67d4c59d4a809e44b.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '76f5c96508d8c1c41e6eacf4383246ba',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/c7c85ed0bf14c61ebe55c96766ee38c8.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7e003bd7d57ec0bbb5d67bf79cad88ec',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/8d35794d33f6526c98c8c92d67ea9316.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e6c58e5f395164aa99c2aaafe2d0428d',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/4038767200ff4716e4555cd6ad95fd37.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12f5c89fe17254c3c9257f995a826394',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/16f6533ea30ffed783ced041b2136665.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '89d1251256b2c4b7c1db12206866eb51',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/8ac39f2ba552d1c2ca11261458b3967b.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b4b1b618d6382537cc9ae5bcb8501cc',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/09c5cee51b0413ae5aaa88173a68c838.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ebc28ee6891aafbf10fc164e638ee91c',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/29c21d955d8239676eafebf340a2b13f.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71aaab651368496f405f1129ce78b554',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/a913f6d501b38ba8b3adc7612f4d8bb7.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c45be8bf6e58e3db241a62f2e0e3753',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/a354a9b5ad4045986cecc431369fbebe.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7cbf71e5b0a7a439be875525c7f679b3',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/01ec151e788540e09ace10e3f899f063.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '99f2a08e9edd3e5834642fa29654081b',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/430279547c64f5e30d949882afb580ce.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '063cbb0e171eddfe53a3192795770585',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/dea3d13ed9398a47e6fefffc35b85762.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fec75baefde6d78f89e7b39b5c371504',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6644a6c0ee4bb92cdaa42e505c2c2ab8.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f348b9157bb0b8a83c0916b339fae702',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/99254a7e594bb43089785d3f7daf204b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '448b50a94ad0b8bb165e67746632504f',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/860e0ca70765f3135fb86b6fcb9433d2.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '00861cf9287b719f2f87b2bd32345736',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/111b146af305d11eb921214013f6fcf5.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7d6d459cc5ec077b3049c4b59c450ec7',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/901b2ff503e1905f46ea4959556fc6af.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04a0616925bf4227a31159ab1ff1941f',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/1c5b228eb1a3cbf1eb3959f5e9565b7c.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c69d70d3e06d8efece4672ae74ab3a2c',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/9cbe8185e0a6238786c022d574b17f55.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '046effca16f71fdd51e3371fe5018f60',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/9f998ed7febf7c379dd0300f75877098.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a520da5206c848cd1ccb21eee4c1c29e',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/90dc473e768c1cf3da43e3467e396da9.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8fd7f6dbfa89dd6e641bba9d07e66c37',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/e0d19dc3fe5cecea7e07e0b4776a378f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '38095aa50de62cc3708a9f79d6524468',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/b7db099a72d6c08a0aefc0bd73e6d753.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aaf3e48d798e626bed560fdb43e97597',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/31d61e2dec56d20280ff05e7fbac9fb6.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '93c10008f6c50182ee3071131f899d38',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/20ecac55bb0ea7ad18f653a64d64fec4.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12605ad92c21f1ba314f4137ec855e6c',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/5782d9f9f40b9440be8761bc69b67f5e.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b03c5cc805637af396a2c93f93b5626d',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/8270f534aebd3a59e9c4445975ffca73.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '021b7d4e332d56d67a3774ee096a93f6',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/1afe0762e7607fd12b4b4bddfad4045f.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8da9b71d58a7dd1327dd0ca8124d8e25',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/d6abf552c3596dddf17475c51fe0bd26.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '842ae0bd4a9964acf26bf5a212d8eb1b',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/79837b9f593e46e3b9e2b85762a1d499.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8b95144e0ccaefe74ecf89b030d282dd',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/66f47b4816925bf42562cb353fa71db4.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5efdb63e16a7a79ddaea813c95603ea4',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/eeb003db08d8519a6351b9fbcede8bc4.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '943989a1ab554a7b2468186ee89caa65',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/374e34bf5c969d6e4178dc32e8b80d40.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2097d5c4860a395087f6505c80e95d64',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/418616c86af54f598a97f35ce981551f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3d2822792b9fd028458e040368f402b9',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/5d551dd058a546a016f0930791052299.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '961e4a481ebc9f22b01d67c403507929',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/f71bfa0bfc35179d8652a6b6f184a61e.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '26e45ab0cded75df6c1bddf9103dcf12',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/82cbf8e9f7af04f98737ff382d8a9ccd.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8a39c8f052c505afeed32e6734aee667',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/e478d998b961659d648bf025b3d93aaf.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '626459187dbe7b2fa7b70133c936f629',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/3058766739f9d96e4dd0084f87cd8705.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f347264a23cc48ac7333b6c537d8273',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/cdfd8deb0c1cf964836c72633de0471a.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a95f5ccb8bada5664c72fd679b7f843a',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/ffbdabf4655b0b5a09adf7cf63ee3dec.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5ddab6982d2c16d8106a51fd63c17180',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/3fdcc7b2440eb2eabfea87f2f1cb9905.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7c7170afe4fec7c4efcc8e4b2af3c3e3',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/5b2bf9d7a5a58129e83c75a579d31c63.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f2e90d1c91af8ebb2a1beace3087c8cc',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/1425b3a6a7f27b785a2059b643f9223e.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c658bfd7f7ddf884c1b0fb52588dfcf6',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/3591fc62c9975329abd48aec22f4265d.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e42d0952b165fc6e4a3bb3834b7d0c5f',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/8cdc85759ef0cc51793c623a1fc7c296.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '453e3489f99dccba46fb9a8854cb35ac',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/1562c855c20ef5a29ed8ef1468de5779.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b77fc0494771fd55e0fdd7a9fbfb3ad5',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/cec1a1b4c14d06b134090add0bfd3932.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '92414eccdfccf3742e0cdf6e35bcd769',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/4a997257ec56f10bed3b2f776bd7d6c0.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5f6cf7541b0b80df05d67a6246e00060',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/ac5d7bffb2bac5bedefcbe82201fb0f5.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '15e841ec5822ea67864a11d6cc39a721',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/8f45152905791a5ee1f17d2f62a234af.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '304187ab4cb216a577776c73439b23c8',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/bbdb929935090a783aeb8669673b029a.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7ec261b0de6ee2d4d759fc326a9aa47a',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ac0401576042916d6de73caf9ba6a38f.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28c2b81a02d3a539db4603569e3944bf',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/8a3438785fda6948df40120e1089de43.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ae04cbdc56a32ac91af12158da318b14',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/d2b768f4d6bfd9ba007af2ac66cdd348.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4779099b9dcb8d792fcbeacc6e303ab7',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/017f6cfff37c97e2be39d13a23cad7a1.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e57b4458a6efa0433208111443e3501',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/2d7790cc8afad76a1902d6914b52edeb.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '85ad8574c94a59d530590763c23de1b6',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/97b2096159194a4d1b18e6b67c66e86d.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e1bc3899e824456fa9f57a484b321b3e',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/f8cfd226a10bad111aadb8a688d778ac.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e373a72bccb782552cab75f2538356be',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/bc78498b1d07fba2c07c52646c53c8eb.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f441d297eded3dc9065c0bc338c6801',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/08770190a4e34123d3836bb674a8cad7.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5fb6f51c5c3bba4366cd675c0d4273e1',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/25e7bf555f65a738fc6848455315bb2a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2079e1cfa0d4485061841a178a9f6520',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/f98a87ef607360b66c58c324634d45a1.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb341c412a02d2ed7cbf8b7fcfbf3f1a',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/a1cfd084e6da7e22e36174c15e434ba5.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6df999657999ac869ca8e4029e79831b',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/a1073f27629f8edaecc3920ad12632aa.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0183fa9d9a4b4cf05ee6ad1cb6fe8fad',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/ac921fa695029a3f522e252d8c36ec1c.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '448de4b3374c93df110c0a7e73c22de9',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/0442693978b2d536dba1671954980df7.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3028eba901cfc6a62e534b3f3a4e07ae',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/a564b059352bdb0c210411e9a8ec415e.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5d748ffc8fdfa2ba04522b2b4d656fc6',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fad7f8d2424d4d912a99cc18eb5741a7.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c6af420d41dedb3bd7e8d0fbbf0a915c',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/b7524379959cb6a3c985d3bbcf5712ea.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b4ade3649297a15994f4ad9b982af03',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0b2425a69407101a80ede78f9506da0e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ef8a5a3145c4959a5c0141e7bd693821',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/3bf8690de5bcf2a6b2db6b336f7b9351.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c7a01c892c18980cbc37f7f1ecaff6bf',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/723952d6d69d381c1b59a43230c4bc09.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7c643c96651d85470d05d561c9603a0c',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/f35d923e36feb6905be1806708064436.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b6055b5bfc1332a5371a2e701e9c7746',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/9b27022344303479d58bd98bb9820c62.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8d9fdca5a7e7be95f178b2420c5ed4fa',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/7bf2474a60a9a6ec8840f56a1d1d465b.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bd8b5249c05a3e7ebfc44124aee283ab',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/ecba0ffe97a8367b9a148669352a7204.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '89cb4a619695b3ef98e19eb495348469',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/18d2506e5061113061bd501152156310.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9e22b75f6a2d55d74b7e616f8a7f2b61',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/f6d6a95a53f19f241a6e5a4706f990ee.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8519accbcadd1c212e41d8d20c6c5075',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8228c60229f1535cd9a7df9b569ccf2e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b0408d1ad601807a12e67d9b74a09bec',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/c134c23ed9933547627987d0aa880ed4.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f208b4d65d540c4e7aaa84d3af1756b1',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/d6fcc658a0f8cbff73b98d3eb849466d.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'df865f0445157b26625475c4d583bbd1',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/bffc3141dfadb8e36d688ea7af53f489.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd02c506df1f036ffdbf5c0a09dc42219',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/1f35660c2cd1d9ca12af52afea439696.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e4ba50522c1e3d54961ed9fa60643fd4',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/34afa24f6640eed2cd3221332714ea8e.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f6d3e26294aff3e70f3aacc382253386',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ae8854cea995793978b112fc2d3b4036.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '362051123c30f8509a34cf948096516d',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/2725e96adcc81ad2faf5d8b68cca5028.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '80c2dd749c531a8c6180a4a1dfcdbba9',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/8586e41d90dd15860cdc2009232ffdd4.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '117629d56e039b87d57996998a6885a3',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/890fb16fc17a9b16afe40a686e19b6bb.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '14b4aa05ce9afd7f55bfc6453089c4a6',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/2ed59bdc673aa042d60c1ebbfe19486e.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '374bff5d12f7cc7b2e28081dc5217703',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/eb57274dbfb737746158f9305054aa45.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2ed6fe024511f3c19012b2923920c344',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/260527027bd21c0d8fec7b50c62d1cc2.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a22eba83aeaef21738d8bb8bd4dcbd95',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/4356d7e408a4e36047328f467d3a83d5.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '34df04e6b8c993f4201ce649af33043a',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/f77da219720aeec59fd60580cba8231b.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '635821c0edd3eb05429b0e3fd9e5bbd6',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/323fc6af8348bff42c4d82c9dd9285e9.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'baa19cb3303c9721e17b218ca5b34c23',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/109e281d8911b352df3ad0eb4eddf800.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dbe2deae038716f8b7b90e358b147a66',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/40db6fda503cca57bab6c7b2fa85db97.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '791b0d3a9cf96f12fce17c00c9e0f797',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/9ec0a88c95a1d02e58e636065c98b1e2.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f82ce2ed9a5b2dab8edbee9edba883ab',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e9ba52197ad443e9e960b24ef13071be.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6338eb38c3befec19faed375742f49d3',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/f8726fbe33f17339a03623c26040a2c7.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6ffa130506b547a1304731d1fa239c1',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/9ad8cf85d467f6888047631a7c930898.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '846baaf28a0f4c22f73f6ec315f7d944',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/90f7a354f01645fd70acd1d1743c9ab4.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c5ec8655b26f4dca343473a0efe09398',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/24062684bdb7b9417415ee03161330c5.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '817b94dead95618cac214aa25d3a3401',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/8741079277017c406c003cbb905abc8f.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0729b110babb13ef03bfc097a33f15dd',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/424de4c4aa71a37bc5745d1f57a45718.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '27374feb2b39d7770b2bdfb968fe8fe0',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/d1da0541f0c8c4e14d9ea4146db2fe9c.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '75cee270d9b1c582c1cb9f9d711e9afb',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/a7730406b57c5c99182037baa237c581.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '812ab845db10209f04d1b0009c7cf0b2',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/16e73a02301d70c6520852de0036f985.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '39ccb27de42a29b94cb2203493884ea6',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/58966056fa87ad7893cd3980760191ab.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '38d19576e8c1a1a280fd9e214c42fc38',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/882c1df54de259c3438c8c10cc138ba3.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ebf58e6d389a83452960ae5878b860d2',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/ff87a97c8e5640b6fabc3cb55dbe168f.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f40fcc33fe0fc0594d11e09b49760d3f',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/5293de1f1da594511ead110ced6ed13d.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '055be044f850847288fa4f076f4877d6',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/db6a9c5964df0929bb7f0a379ffbfcf9.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dbc16d736778db3cf0c74279c3d807b3',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/272283726c15f8b77b166c1dacb4a9ae.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b35f5278733b5c51546c277ed7360145',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/a320d1fdd1e927bf5f9e7000eaee3c40.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0013748c07335fafba7dc1bcbbd0d7b5',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/c745dd4dbf25871dc3d82543faa1152f.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f3ad4bec02fd12b467b8b36c69d7f0c',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/04289d266308fd3872f2632f4eaee3c3.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8b555fe8e8334e6fad653a48c1eda9e5',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/a6534471f1c14a3dd7d0f4597721ad49.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4daec81f57c8da8b168bc94eb54d28a2',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/606209993c13cceb228de6c71bcf99c1.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '94c2db9debb40451d80cc174ceb9f98d',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/005153fa2816d646515807e4c209f59d.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd7e51f8281531551e59425748a050ba3',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/3517f1763b70f8d7f06e46b6428f0b20.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74863450b467291d1622ce2f9fd66f29',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/bae9a6a36aa2ae9f5eb2ea219cb17b9e.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbf38db22b343ff998221bedc3825830',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/891f1c74d62e88e9c6fa8e4f5eb4bd3d.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a4ce26caf2e3c1f117ba5b6a06c5bcf0',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/7203485f4eea69572476bfe1b5e99298.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b68c5646c2cc37b378d06a291c6abbef',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/9adfbb72ac886b33eb9dab8fed73e90c.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0328f45fa0dcd4a70e692c5d342b9377',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/c7b45be0fddca42368f9a3faefc132bf.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '24375615565547a63f4efd12ee571a07',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/1efa695af0c737c496b988eecda16c3f.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66f7323d9f855cb836f948147cca0a08',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/68c7208deb2c02296f8990f872b01a01.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0907e5fcdfc0f2a5ce1690fc7e42a64',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/581fb29e1454c78c1f103791ee077a99.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3a6fdaf5131ff1db9fa84198c52cfa71',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/9d2aba3c8d0cd9843e42d9ee6a462567.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1cb65198e83d4c0bb650b346514b9769',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/e7ff346feb8a06e7e66b60d438aa062b.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '93ba1aae3dffaaaeae3dcee2c41c4eb8',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/5b1c80300f0ec16bc1b50693e1805ea6.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0580627bc45d11f75aa9782b645fd6e0',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/8c08479fe81d96addf6e598b62c2c5e9.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4146cc17b5c9e17c79231dd5111c31f3',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/3202ae89ef041deb1235b0ef750d8578.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f3c0fa91653c3a5c6c649ff35a72949',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/f4b866425f0ec55e73909f76035d6131.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5ee027c4944c9c1876d523f39957639',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/353f7fffd64b23cd4f1f44011dea5636.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8508db2f8f6fd9dc6905ec51237cb5bf',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/a04a4f7f7ccf57ea95746d89b5c39cd9.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7000e41042854b91a08d57e419543444',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/ac2bcedc593014ac9d25525a0c402263.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '16ecc543543d4429bbaff541dd5433fa',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/e6715930be5551b9d9a2026938e2439b.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ea1250f2ec4c87007f7e8643925d07b9',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/c751e567960d062f4f3d201932458500.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3dc24b4a7db804feebda4640d74aea14',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/f58c8c4a9e66f754716ad5f72564bcf3.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '23650eee7dfbf633a2ddbb0f15654039',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/bf35c72b399d12a87098a2673095f4a0.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4d6fb5aa83c93638f5459328ae13823',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/01dc3f477d1d0b9a0b572778c6502919.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a84bf87a59f12df57178e319d3a08418',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/fbfdb710aa5dd1ef5f6cc774942031db.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd343832bcd86e0cf83a024dc4ae4a42c',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/26c88eaddf391024515f1dddbfda80bc.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f4b9ff5b70b60284cfcd3ae557c83d58',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/b7f100a5bf0fb5075dcb486c406f5d61.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bd91839928d334b9966a01bbbc21ec92',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/4e809b5e9f89200a454bc93246797822.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6fc33e45a257734063ab1a8502c70312',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/9a31e3ffbb3f81f97242359560342614.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff7553bc3832f85be7b7b8e472cabfd5',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/443dd0d2194d2625dc45f2bdbc38858b.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fcd21f03a506304764851e5953c5de12',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/97616781aadcdc717469a1efdf833ebd.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6c770d7e1bb84dcc8319964437a2e45',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/c5795f83561f30f8a8fe11e8917ff1f4.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd894f3f0a5c8118473233fcd7ee05a60',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/00b0fe1170c595ece42545434858bfe0.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad07a8a5709ca5121ee2bc20af01b315',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/f1b7d3af9914b3250070de4d8478ef5e.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad526dd8cf0ea404380e781004c0f29a',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/0ca26c0259dedde109471dc79a72c7eb.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '97004fd73d129ae72843aabfd9cc4282',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/59bfdd3ed8d6fdae15d85dbfb27f070b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a058383db4bdcdf359bdc86104103630',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/43d975050832f67b285bd301a9acfeb8.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7db91b149f9fc39adc7aee68ca88b50b',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/7594aee5be712d6e42fdd258fceb53f3.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '83b4874e093f79965f60c7cc5ab61957',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/dd154d6e5c198f10063e1e9891625cbe.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fc05f3ac25f86d9395df8a7a95fbc76b',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/824c3bae5aa05400f9577d0ce95fc7dc.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08d26765e675b769855ba2c11c6f3a7c',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/fd9823a8e2a5ecbf8d8d5a92f8744717.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '41584e0bfbf95a4dd2c3e29543da7fb3',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/1c86b27899445d4fb1607879649f6169.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c9d2a0d2d6b7a66443cd5020452a5275',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/989c39edf84a2d8fe3d4fa788ccf77c0.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ddd623eb294380bf9d73e72263bfbcb7',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/d591af943c127678e8694918776053b3.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9e360bb117d63d1de0a55f059bc61359',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/6a7c0bfb8782db0ec4f84222a9bfeeef.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f942932f226364c8affb564b43875d4',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/d3492ddce70c9ab2af1907cf2a6b2fb4.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60c301b532bcead757fe63ec70a6f6c0',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/1a7b277fef6d84ab64b1a9fb0a395243.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4dc7e329dca5db180a8577ef4d717a34',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d857a628a0107d9acc0e3e92df866da8.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd325bb407538d80bf7baf185effd361f',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/862e9b3fa21979729c95c9acf1c04c18.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '40040678c71ce54f077b9a9a67490aa4',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/091720e7da389e40d08394e66e827153.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1949ae54704847a6c5ee90edfb53c019',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/8327587d1355ef891e69615186f6d4b0.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '39055497224e41dd71b0e06c5d23fc6e',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/5111a2752e86a3a4f4b9aa8842057ed2.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f855ed8ff365d335116a8dc0a97d0dc9',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/b754d53b5cd4f69dc5cb0a7e62186453.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6b9585cb795c472f3fa5b60e016c1f79',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/b37f52f875ccd9e2cb62c5d7faba5ac0.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2b9d52aa9871c676438849e6bcd61163',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/a9136fdb0316c34466d32b42b1c4dba9.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3766e852cbdd32440242eac0c4d7467',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/ec909e35a94634e2997a2cf2f87ef19d.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c1f2f36d14bf127a778067db5944b695',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/57f10daec730c1d3121c8081772d8759.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f54291758fa15a502de89f07f5269524',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/e7156517c704258006cf5231ed446ad4.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f7c3d81e2286c06b08c44fcfc7a8780',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/92f2f3b63dc1a790aabcaf6c48de1f77.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1ca95c56f2f9a62cda357e75e5fa3bb5',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/1b1fb31e63fcf2cbfabbe5a8388bd9c9.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '12da9379150562c1e944dcdd9a0b0db4',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/68cb1819c8b999ff3ec8db2c1e3f4593.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e67271cadd3b75c126fa6d58c754b1a3',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/81d0a981be1b8202717780f3e795b89a.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2ee9bc129b577017783edc35caa159d5',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/3788d99d157be437cbd0e9a8ddcfd0eb.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbef3eeb4465ff349024ea98ddf6b0cc',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/32744dd8a3244acfe33c4a72529eb9eb.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c8233f7a84d79a6e6ca6114ef42d1995',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/6c224d5c2c1ffb328ec4366634e4ed04.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad9fc5210f0484765078815c56a39d77',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/046c6893407b5f1341d837cf91c47737.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f4b65653f173c08be1744484ce8b094',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/5bf6bc7a84816f385dafd3182cdb78e4.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '791890df72cbb36f791f52246b0aa1ad',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/2a208922a5ebe1ad2352c9391142adb4.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da992763095b41e1241d861bf94577d4',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/4afe6c34fcc436575739cabd371e6584.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '79ad05df27fd42eb1ef313f1f683688a',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/da4ddf98859afa9487a963089e5dce5a.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0ab4cf22da36afd4218cbbcf492dc42',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/4230747ae41866003eb3ffa659b39ef7.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a3eb5d31fc50d6111309b52c7a90df4',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/c42c043923a758e68c8edc4cd2cc6ec4.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '84277b7a07e56dae90877a4ff2ff8552',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/5c5ab278a4a4de26721cc4bc9a2c4143.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7197fe3fab8da37c2a0426f003e7518b',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/758a67a83e289c9dd0195a9cf3fa3d8d.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9cafb922442fdd67fa3e876a7c6a7a06',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/b6c677262d85c7a845eb105bfce8b0f4.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6766b8c369daef8fc15bc7654f4b49ac',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/5e7948f70607da49f5cee5e60521de0a.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b18760a8575c50c0de38bfed2d76d6b',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/e808103a25335bb6d58a06adeb82575a.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff53e8f73626c1d9135de081463e8973',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/9f3dedb64297d9d0110a513e14b5e55b.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '23336b657549ca836b62541272df5d68',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/be4d1172f839172170c0d1e4f5a3d10d.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ebffefd9519dad08941daab880abff74',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/82aab269101d5d9dd9810d98ada3f25c.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1940b0c890e80f2d322a17a1c11aad4f',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/ba7b0c503e29ee9c3a43e5e8be198a83.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ccf7319c126b9e45f17a741c934eb574',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/92d0916c47eed9a7a3f44c5d660499db.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f26b60e337717ce3b693c07662ff0753',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/3c40aebf5ff893e165728004215f9769.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37af978c5fbade57cc7f24b87bcafe32',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/0626b4c41f4ad009e1e402e97fb3895d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '85e6587806d39dfb5b8afb7a23ebdbe5',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/24a7db3e518acdd6e9bba48f8e23ee2d.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42930926ccedfe4440edd8c4be438337',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/aab205a9213a5796f2e2c447ba1ae542.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3a361a13e0e5996af048107e2f28b0b1',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/eca0554f5dd3ed99accdab8ec8f44e57.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3502991fa1c623871b1896ffb967a2e7',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/243e772d5e32b7c4393d1998f5e0be7d.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2c7d3550ddbd73a25cdfe3c3e2d7afb8',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/df3b98f743e2073225a7cf9a909eb1fa.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f7aca1f593b3d5bf2727fc9551aad5fd',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/79b4741d305c7fd07f7175bbb9306888.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad4d024e9489b5877c7f91387bbc02c8',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/874403991f3af088d2e782cb4c86554c.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e43d53d0debc63162f70b7b01e39a177',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/40a77147d89bd9e51a2d1e4b01424070.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e17784703cc3c05c05508b794f6dc32',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/e1978e8f29cbb0762bdf550386c4320e.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c6a655fb3f0b12c1674ae4ed5e05c18',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/511b14a59e6a51ea1664762c812871ed.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd3539613b31422b0748c41a2804e785a',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/6cc69f3c7644a8e71f7a4cf41518ff6f.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a85aa171ffd370ce0a77637083f17fcb',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/94890bc419b7806ede0950d269ecb869.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c6210356ff3be57cdaa154178270353',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/0b6fb3304d11d1ba00d0c21a3d1299c5.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '93ca5165f624fd82865f1aca5b699136',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/6f476d662f33894a8e6b28d51d47c18e.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '36db1e1fc6f6dea78e925c4b0f74407b',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/e27637af666f3365dad84ba1141c3cde.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0dd0b78bccd645097207a89911484115',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/12e86e9ef3edbf70aa288c03cd71dbeb.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47c0b153edc01f4d1507266032cd4b84',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/882f72f58fca8ac5714bc634da447ca2.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad312915fd140ead4d0339abbeaeb06b',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/427f59ac75fb5490ec0080b8ec266e59.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b5080517380040fd7d3ca05364a111a',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/e31e6ab24156ccbae72078a03bf60c61.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6373b9cf118a95063cec69d729009c99',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/303b744d4562423ab3824bbd8e619920.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '392af983c8844d4509fa7ffc22d3ad23',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/2315ca06e56259c10626af6edf76887f.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '67156c3bb5f4a53c19120ec66993db4c',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/8bdf8bb0b655487b3c81edbefc1cc140.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f5ab9efdbcd37c64c5b53c065f4b78a',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/4d8bc5e420054e8da37c6478b368b573.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21af0929f306b855d2eef26c0072eaa8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/5cc2d421fe39586e1d1bfd1cbea4bd1c.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0eb9b0886f2ca13545bc63446efa451c',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/e787d5b32568cb5766a175ab4cd09cf8.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5551c4cfe93c21378d1ef6d1ee38305b',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/2571b9110a2a31d17d54492c81a7008c.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '89bd205dd01ef9cf1bccf47a6fab14b7',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/56f9d496acaf59b1580e821c4462c927.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd61f9398ada9a72bcb15b2c4265136af',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/a8f43c84073db9f723b86657c4e68d82.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e267b783e00e66b44d2fb7d8767a8181',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/2d0b51e48c2c0ea9a29761f6673c6fd9.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd1853c669acd26101efe3992ced99a58',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/1f6721915640ef10e2496ce61aeee519.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da81873016680eb3f6be03c6dd2dbe4e',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/c83d396084173de12062cbba15029f42.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c69b91a6d2f8ad4016863b0b7344c9a1',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/07336e9166c4e6b7a67734255ebf3756.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c3653b4ec76f2a2397ab2d0a57c0c053',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/0830cd98786dcfdd43129c79bf80c05e.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0134974493175af7061318cec28a0fd4',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/76c10dd089916b3768bb527fc2b9804e.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed57a41ada90447066b0e97deb0ed361',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/f040b4932139fbdeaafd46600bf1ab65.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e42dbdc8de39bcefcf7a15b3da4e0433',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/df594faf6eef596b259878c607934913.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '857af8fe84a7eda0640df3ad25637044',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/60a921bb2a475d36c5002da2bcdbc55d.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b5f6ad5a55dd7c7ddaa43a92925ee989',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/03f87749663f73f5d2203200067b424d.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e891ca970634b10786575a217d09ec44',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/1b1c26a737a2ab9f43e8baddf1ad8e65.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a468ef3ad48531b03fc58de68a47ef9e',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/eb45059a778d2483e33580b0888e3f5e.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a2648b0e206201219db4163e7cf1c8b',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/983b10e086bf1da9498ebd7c72e95677.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd54bcda3d6b1a11567266f463894182e',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/634c03e24aaa6a7fae5826a7ce50c0b1.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '016dfb3be892967550816f59d1358e91',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/d92e663119333b8b2cc3ccf5d9f83b84.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '211a241174430e1d0431137c4a23496b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/b714d1b986341c564efff0430253930f.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '828ee7b71fcc569eac783f0c45895742',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/abf081a7a53192586075612baf50f6c4.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37cd0e884ef01b8bc7a92c63c00dd042',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/3e59f1815f37b2c45175a4a65dfaa6d7.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '907b03410c0c588b7cf14d4ecb4cc7fc',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/c45c6dff5b3c9b2514382a968f0da17b.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f630b5319133d57a92718335d8bcb19',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/d4c51efe6e6b3c6f90998e0fe3ddf4cb.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd7ce7a7825c1510cd392f3c5d6ed9ae0',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/ce34751cb926146b0a62a7af090294cb.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5f3d8981a66ec1e385b8bac82a97a059',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/15f510e2df8779f8b38d3344bdd4b8d4.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f0f65a6b51ec96d3a61fd74bc5df024',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/e1a3b4f72af738bff751eed5b7cd0990.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f00d5ca170dbaf691c5211463279099b',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/e80bb8328d9218484c19100a9e0ac53b.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cee5f960af65b39bed53529d28ec2535',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/9500854a5b360e228daa57ed94bd675f.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e4ea3c4de708d6ca555d12fec362a7b9',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/233d3281c6a7112d55c9fa2c275bb828.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b6b7ada14f0dbb2aeb34142cee2abd4',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/a6f202cfa1999af57e8e1d85737a7636.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a07e6691918652c2b8cd5c9640537066',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/0b2a2a5618f21a458df953a0673a9d48.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72ea306ad7207140b0c6aa5ac04b84ba',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/022139f7c18f6bdd5ecfea2de4736523.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a130ff2403907999c457b510ea8d5b2c',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/ad306011578f7a5edca7879b954d46a1.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f894acdfda784314bce9f950ba8d102',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/0836aee7fb7fcb20d0637abe89d2b9b1.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e6287d6063c8cb6e2d83c7675ea4f22',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/2ae3b0359ab5dd197220b4fee7ffedef.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08223581882e8026174ed4b622d95e82',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/4356127567c84a4b51ec6e25bf20d9f7.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c8c54f1d49577f0d7c27220e0f76961',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/f337983e784c23275fc26335cd80b271.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dd3e13326e558ebe3ef0c975897acfc7',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/dac5ffbec5f75d7f8218dbc2abb59633.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '53c7d973d827ae5c9b94ba1e63c4fa46',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/ea74c8eaeb067c10bf029a410209eb12.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc0b3866a8613b022448858792ec53b6',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/c3cb8df18c6575d8f61f261032170c9d.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c1c985e55a9079594b7445bdbf5555a',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/eb809713ff33b54923283b741e75c66f.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '67089f3cfdf503acf10d033f7d76fc21',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/6fe20012e900d2d071c2a2d88c187748.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aae6e0444e80bd03cd31be8b6231eeb9',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/fabfcc56cbc32e5eddd4d73f2dfee9dc.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f43f2e339b7f08765509804558365b9b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/7bddd5d305e0944491d124d0c6d65fff.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '969ccb327776c013590afef3ceccac5c',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/b0b03db20f5bbeb944469b395a8013e1.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bdfb13356c455d0c2d72f80da590ebe',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/6101a420172eb82e4939b324a562d64d.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8b32f6c006c8553832fb2dd4157fb95f',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/c510491f5ba3a54edc412fac464ebfc8.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f879ed8aab929f53fe5bb510b50c3e67',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/df4847afb566be344875b7cc3afda4a7.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '77a30aca8514cc696d18e42144cdfca2',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/76629488eeb6e0d8084955a0a22b0560.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1f80562aa2a6cefc49f03440e89bdd1b',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/b4f4f86d8256572841521af2a0566d2e.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '29a1c93801a5096ab53417adedf2e2e5',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/b9eacef062043be2a1c7c4eb51d5be86.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8a2251c474f7bc04ed16101d1bae7901',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/1ece2983ea3782c21518b9389dd7cc1a.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7a816a94a8555a14ca29fa98115d82e6',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/fa0fae91273bf97256087ccfd98e48bf.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42b53d0ec899f166a7bee0326b79fe9f',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/0ac63aeba89f29dd58376e96e924dd38.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '53bee34648770db3eaa8c1c95a969bba',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/7f1307164da7ff06a36fcac33dd5da22.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '88390203cffdbdaec8a238f6aa12d970',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/e61aaf0bdd53ceb5d8cf825524f8e116.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8a0dd226b62a72a62799ab62f19075a8',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/86e27b0e2ed8d9a71ddc1731dc7f43d1.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4ad5d845c3bce8d16ccf2ea6427e24b5',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/f4674e7468d58e883c88baee1d002100.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71c04289bf33b5f2ef16969678a2c963',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/89825413b903db2ed6447e5c007798ee.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '768e539680a7b171f5e88ac42acd805d',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/692ebde5c881412f3f7e6f4008deda59.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f20c4283e2bda2dda427d8106579064',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/22374edfd1fb7eff3d5e300b90072a3d.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ae6718054d1cb67c3aa97205bf11fc9',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/a7694967e648e56a2291bcc4cdb141bb.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '690695bc6ffaf0bfd162893b55ba1d2d',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/dd5bb25204a73a453212da7643305519.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08d68e212d32a701273d1ee739f6b1f5',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/5baee4decee2ded0b1a27800cc70a928.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '98ee6dda9b97c0ba3ca8fca97ea5217d',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/f24523f66daf417ab94d102483b627b7.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1eb538981a690d2faf4a7a1cfb1c9d66',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/984556d1f8faf39773fad7f99e9187cd.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5976f1f5ec1d03ca8dc0026c0898658b',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/50c6d8855083cb6696a89e4818f1ad8c.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2d002350e76e724437bf058a20d0bcb8',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/cd82f9a6bddb103ef026c76a8512bb6b.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad5b728b2d32cc2228ae9d1d200e801b',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/3dcb113e7d11a9544f70b05c243d7cf5.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b63c333e8c6ed6b0959d60acbd4d3af',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/b9782cd7128780037d1fab41bfeec920.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31faafdc9c56f41c9becd72e00975106',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/92db7b9b42f2fc56573188ed57316012.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5d4621304e351bc8e56a19d0f11ade8',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/807424e3cf1f102d34d16aaebf3dcb92.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '429c73e938afe9fa0dc7d6e77079fba7',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/a1841e4c8e90ba3f9f52dcaffb23573c.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cd4e108292efef9a24a28d4ff0065d7b',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/cd519c633f82c0155ca6d8255d82e7ed.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f2d78e5907bcbc17718a4d33f085e16',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/a02f038d242e6f887583a2a5cb6ec129.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'afa7ad672e3ce04cec1d7f4eb2497b3d',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/d79414520ddd244c70e759fe980c8c9d.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5f523104678474a8a4d27728d22bb3c1',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/c8a498f0b5acdac6072c8f6b4ef6f75a.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '641ba36e365bb972984699c792e97d38',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/cf7147e82d7c895e619ed7f75ee2ef21.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66bd03b69d842e92bd16e7a93fc8afc7',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/5da118b18cfd19c7451081ce9dffdd9d.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa9c320c64d36bba11f4b46636a7a63a',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/d8e5eb88893a0da8e4473acda499737a.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a4428a8a1cdbaeccf647fc65d8e51600',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/3f9ad8d518cb184ffa2686900de580a2.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '061119ee3179e160384c18e13f34ca2f',
      'native_key' => 'upload_images',
      'filename' => 'MODX/Revolution/modSystemSetting/79df445e4bf91dd930537888b7b0e583.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'af2a5c191e4d4048554337a98a0eb5aa',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/9fe5b4e5794dcb5329169cbeba7a6ab0.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b178eaeed65d03784c1cf8715db5627f',
      'native_key' => 'upload_media',
      'filename' => 'MODX/Revolution/modSystemSetting/a0907589c72ca584e13c036382ddafe3.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5fc2c7c2254cc9cb6d77e8f27f0d69ce',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/58733d34d105587b9d94025384f42823.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '54363c1d87e7e8144bdd7e2669ad22e0',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/70b22f1495c398e6a30a45667a95fbc1.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c2351cfe0166f0126f34491a30c6d54',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/9949ec7d0be689ddd69cef384dc149a8.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '652300a73c9ed4b57ee6d573652751fb',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/3dfa4d7f3c772a84392f87fa3d2462d6.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '095e170e358be21eaedfc781b04ff998',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/2c70ddbdc461741429b2dfa504f2c221.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dfecff36453d5b021ae847b8fc464a0e',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/c9d688e63186fb4b00c57f39ee433020.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1bb4eb726849b61988d3ef73cbe5a8fd',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/5fab788b1a593e7315d9cedac4322726.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '03f88ddcd3a451466f21a8f5bec0901c',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/43766f919a26a1db02abf270966b346b.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17fcd1adff8a54d677ef23ee04a32672',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/bebeea31dd99ddc9edbb4369a9c7e72f.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72515d9383485af4be100d25d5726750',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/6c62f6c73cc322ba931cbecefd5e1b6b.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd7afc104f024024fe9b2785f7953b85a',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/ed80c883244435985f985ff82d059a07.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1b043b95ca04408e1721dbcb9a75e12d',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/5cce0b2a7f563738335f7ee92e48abc2.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b949558e58714c6b62d8c9947956c11c',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/62f70a9318ac39ebaece0f8cf1eb895b.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '613c752c62626a8758fe08a791d8c0b6',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/ad5a9b53f897e3cb5604a23bbb4ff700.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd41119e299998a4c4e44df3b3d51fd8b',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/cd71ec4a7ff9a8e4ba36bfe300f19337.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73acc8c37bc15f0ff3f9bb718d6e9345',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/f1fcc34c150842b8d226be777008c23d.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11ef171fdc71501dba4329bdf83f45f7',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/1e83d22e8127f5da2fa0c33b74b175f3.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6bec5db53aa3fe7e2f0e1147f7956959',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/5961d4363fd74c8ee6867987263dcc1f.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e3b953878f56fb74f5bba23d1f9a9ecb',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/2a36bebb4d91bee7793b5ea6d948c88a.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9131a31362a46d06fb1f1a2499696810',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/1013d635a0e2125606642d64dd72b2e3.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b9349b06765ef0d3c3571f86b40e2416',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/8a892996f60551c7d55c18feba3abb78.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91d74fb838bb46d2ea656b6a0ebc65dc',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/2e6e16de6e34eb0decc0ca2cea8e995b.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4cbc434a0bf4f68f32eff929577882df',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/6c4005c40c663f09d69d10c966dd0f16.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5efcdcf372e2edb13dca6f658a4802c4',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/72127072734675f3f0b44020fdada0f5.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac5a0ebcb32bb167e0cba8473777a955',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/cd57e8d33fd6059c2c6eae7ef732e433.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed1d3775826db8d6ef2111e7f74782be',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/c3638aa471147bb3d416d4179539c113.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b5fb9872b56f95f89d88c9c3252a04d9',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/4317a0302f85f796d83b17967f010d85.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '5c99201280b7f7c69e106b8fae4f9cf4',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/0898a4dcedd017ecea4e0998e60cd313.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'df132a37407475b0d4dd35c300c4ee2f',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/d0046d4a4edc4d5d276bea2c5ce8f667.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => '248864b0356a1d2d99d8110ab22caeff',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/ae61e70aa01aba99e608d8de96d382cf.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => 'e2322116810e48025451c413582ddd2c',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/13baef14e04c1772482805425e4e55dc.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => 'bd816ce909ce62ff57c6d05463047401',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/260f881d9fd8156b89d54da6bc890fa3.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '98ee3880f315e834477acf1f94e2d748',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/09183e295868f968fb10aaa94c1a2263.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '82fabe1938832afd35538bd9580e9b7b',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/118119852d4533095b82c0bcb61268fd.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '1dda68001efb229d3fdb260a564672cc',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/0585850807ac37e25e7a190c96e0122c.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '0f84c9c3336ee711da91cc922b162a3c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/bb478e9050a3515456f8172015baddc7.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '216585f4ea772f8b764b33acc0aca96d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/793ab584de763170b5a615fec3111122.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '0341799cc2112e34e62fbf429f8ee839',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/bbf73c0bc1cf1e28829650cd7ebdc45e.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'f675fdbe95dbe467061f44bb2c140ff7',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/35c7f8fcac1dbac4b255fff5e83ff701.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'b1e52d4561cefe1bba90d6c8c3f5a19e',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/6353601c76b92b9fe2c0318fd2fcad25.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'e499338280094b8fe06d1264bbf6a747',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/d16d60e359c11a483d7f9e53909cdef1.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '1cb829ad04191a36dc4651a06cf7d66f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/46d6cb40495f535b35e42e78a385fb9c.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '6057a85b72309f90fc4419c2c97e3f73',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2dc1db1e0b5baf04c6fe740a122d2a28.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '2c3000ed7879e8a6675e9459a124ccdc',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/e8aadbd296bb95b52898012967441b4e.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '45ec805b942b809f90297f4439719e45',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/a81061b7eac44eb164c497cfa6618c03.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '0f77cc7c9374279aaea19035e4dff589',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/7d61193611ddcdc9b1227c7ed621c581.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'f88201888ade9a44101876ae3aaa4b2b',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/432936a597b9cf0e586011b4e5d904c3.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'f598290be7d4061f4313a3020da7cc3d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/1fb7e587cd70cbb5e3580f881fda0688.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '3408e082a28b19ed2eb66310c1902b8c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/10ebc6fe649fa82fca069d8a64a629d9.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '5c0e786783e04c815ee36258631fbb86',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/aef63e10f3c0eaa8c50969dce4a00f06.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '26287dd052de015d5b81e28145860b69',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/d79ba88dff8479702bc3538aeba5e639.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'ede8ad10bd25fce0113576546a80e077',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/b299cd11b1e73950c11012aee20a1e1d.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '27bda3ce59bbb91bb52e4fe17f387d75',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/0d19b3dcc6c491d888ce6f46dacb12c2.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '45c7c5d83321dfb74086551157ea5daa',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/9f242ffd4d566d94f823201aaa5f0f63.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'b7b4468e8161c6022b214c544bc749f7',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/ae12a24d377d51de4d26984fea03021a.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '0a7a7566ed678ec4e2452fbb125a4683',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/f7ef7f2386ad71b447a6f050f186c654.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c852c61bdf2cf7650cb684e535d174d7',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/f06cf44b054e96a32029d627c4b2f96a.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'b0809764d0436b2610bdc0c492b9f3d3',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/d8b2865f28548f2a0d57b3025d2bc35b.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'e1ad357f18f36a65e1f4b726104c0b5a',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/254be78757f6938641541e185a703685.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'f0a5043f5b4dcf47258c30b0dc2320b9',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/577d527f72741e141aec1088feefdea2.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '1fdd32a0ccc06607bfad2c307b8544fd',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/ba04241c490aa73eee9130376eecc12f.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'f1ffb8cb38e64f7b3b710958efbf1115',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/adac410d4dd1d5fe1153fee71990e888.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '29688f876df1709eb30dc43e6dbda2f8',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/8b53f51a7beb2d82c1e7e03656db8d4d.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '305f27ef910c6abc6b8ba655d55d910d',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/37287d9ca4afa84ec6c3ae6bb963f66e.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c4ff8c2744b7493fb90561975684ecb7',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/b248ca1e68dfee73c86e4617d1d98873.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '60903e02a461b0696db5ce37247559ea',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/8b54d3a4e7d541f35678afcce9238f4c.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ff94b28defe6913accc1bca68d1555a1',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/5b814cd0fa2324fb82f48db2e4fb1cdf.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '6949308c02a7207fd96ef6e3d754a014',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/f340ca63f5bccd3791cf5b124e24bfee.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '557ee82868e3f48cb6d204632ae1bb8e',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/bba8f734953b2e5f42a77a0404fcf004.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '88903f7be72881862dcae6299b0499a9',
      'native_key' => '88903f7be72881862dcae6299b0499a9',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/e30a8b7f57bf7dcbf6e7ecb93e7688d9.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'be12c2b43bf300067e6a2e19393fe3af',
      'native_key' => 'be12c2b43bf300067e6a2e19393fe3af',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/876a7bc7a7ade06dc88401b1a04be7a8.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'a2bb46670d6065678d350ba5fdfe1d60',
      'native_key' => 'a2bb46670d6065678d350ba5fdfe1d60',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/4c9eba4f75dd2c9fb245b95abc8fee27.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '741d61e5c4cbfdc900685c6f386dbfaf',
      'native_key' => '741d61e5c4cbfdc900685c6f386dbfaf',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/51b997dce5ce7a0cb58d1ec3eaef22d3.vehicle',
    ),
  ),
);