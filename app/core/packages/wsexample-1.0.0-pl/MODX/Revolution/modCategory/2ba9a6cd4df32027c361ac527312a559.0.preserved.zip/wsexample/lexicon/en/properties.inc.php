<?php

$_lang['wsexample_prop_limit'] = 'The number of Items to limit per page.';
$_lang['wsexample_prop_outputSeparator'] = 'A string to separate each row with.';
$_lang['wsexample_prop_sortby'] = 'The field to sort by.';
$_lang['wsexample_prop_sortdir'] = 'The direction to sort by.';
$_lang['wsexample_prop_tpl'] = 'The chunk to use for each row of Items.';
$_lang['wsexample_prop_toPlaceholder'] = 'If set, will output the content to the placeholder specified in this property, rather than outputting the content directly.';
