<?php

/**
 * @package wsexample
 */
class WsExampleItem extends xPDOSimpleObject
{
}